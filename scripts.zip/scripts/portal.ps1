﻿Add-Type -TypeDefinition @"
using System;
using System.Reflection;
using System.Windows.Forms;

public class Script
{
    public static void Main(string[] args)
    {
        string title = "$args[0]";
        string message = "$args[1]";
        MessageBoxButtons buttons = MessageBoxButtons.OK;
        MessageBoxIcon icon = MessageBoxIcon.Information;

        MessageBox.Show(message, title, buttons, icon);
    }
}
"@

$notificationTitle = "Jira Portal"
$notificationMessage = "Hi! IT Heroes are here to help!"

[Script]::Main($notificationTitle, $notificationMessage)

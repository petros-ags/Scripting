# Import the BurntToast module
Import-Module -Name BurntToast
# Create the notification content

# Display the notification

New-BurntToastNotification -Header( New-BTHeader -Title 'IT Team') -Text "Hello, we are here to assist you!", "In case you need any help, you can raise a ticket below to our Jira Portal:" -AppLogo .\efood.png -UniqueIdentifier Toast1 -Button( New-BTButton -Content "IT Helpdesk Portal" -Arguments "https://jira.deliveryhero.com/plugins/servlet/desk/portal/270?requestGroup=817")

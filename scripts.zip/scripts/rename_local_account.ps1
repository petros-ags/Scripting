$oldUsername = $env:USERNAME
$newUsername = Read-Host "Enter the new username"

net user $oldUsername /username:$newUsername

if ($LASTEXITCODE -eq 0) {
    Write-Host "User account name changed successfully."
    
    $restartChoice = Read-Host "Do you want to restart your system now? (Y/N)"
    if ($restartChoice -eq "Y" -or $restartChoice -eq "y") {
        Write-Host "Restarting system..."
        Restart-Computer -Force
    } else {
        Write-Host "User chose not to restart. Exiting script."
    }
} else {
    Write-Host "Failed to change user account name."
}

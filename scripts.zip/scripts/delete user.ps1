<# 
Description: Script to delete local user profile not used for X days
Script Arguments: "<No. of days not used>"
#>

if($args[0] -eq $null)
{
write-host "Please enter number of days in Script Arguments"
exit 1
}
$dys = $args[0]
$ProfileInfo = Get-WmiObject -Class Win32_UserProfile | Where{$_.ConvertToDateTime($_.LastUseTime) -le (Get-Date).AddDays(-$dys) -and $_.LocalPath -notlike "*$env:SystemRoot*" } 
if ($ProfileInfo -eq $null)
{
write-host "No profiles to be deleted"
}
elseif ($dys -gt 0)
{
foreach($usr in $ProfileInfo)
{
Write-Host $usr.LocalPath
Try{
$usr.Delete();
Write-Host "Deleted profile successfully."}
Catch{Write-Host "Delete profile failed." -ForegroundColor Red}
}
}